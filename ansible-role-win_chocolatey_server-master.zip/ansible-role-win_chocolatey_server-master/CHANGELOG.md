# Changelog for win_chocolatey_server

## v0.1.1 - 2018-07-16

* Added extra notes around the automatic package import and what happens on a restart
* Fixed up issue where the package will fail to import when using the path to the Chocolatey nupkg
* Only install the `Web-Basic-Auth` feature if basic auth creds are defined

## v0.1.0 - 2018-07-12

* Initial version for the `win_chocolatey_server` role

