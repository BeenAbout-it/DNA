# Chocolatey Publishing

- IPFS Desktop is available at https://chocolatey.org/packages/ipfs-desktop
- Scripts present in this directory are automatically executed at CI after a new release is tagged ([#1697](https://github.com/ipfs-shipyard/ipfs-desktop/pull/1697))
