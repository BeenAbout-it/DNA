module.exports = function () {
  return {
    start: () => {},
    info: () => {},
    error: () => {}
  }
}
